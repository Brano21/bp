#!/bin/bash

FLASK_APP=rebind_malware flask run --host 0.0.0.0 --port 8080
